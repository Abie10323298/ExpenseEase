package com.example.expenseease

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.expenseease.Data.entities.Category

class AddCategoryActivity : AppCompatActivity() {

    private lateinit var viewModel: CategoryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_category) // this must match your XML filename

        val etName = findViewById<EditText>(R.id.etCategoryName)
        val etLimit = findViewById<EditText>(R.id.etCategoryLimit)
        val btnAdd = findViewById<Button>(R.id.btnAddCategory)

        viewModel = ViewModelProvider(this)[CategoryViewModel::class.java]

        btnAdd.setOnClickListener {
            val name = etName.text.toString()
            val limit = etLimit.text.toString().toDoubleOrNull() ?: 0.0

            if (name.isNotBlank()) {
                viewModel.insert(Category(name = name, limitAmount = limit))
                Toast.makeText(this, "$name added", Toast.LENGTH_SHORT).show()

                // Optional: go to another activity (like CategoryListActivity)
                startActivity(Intent(this, CategoryListActivity::class.java))
            } else {
                Toast.makeText(this, "Please enter a valid category name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}