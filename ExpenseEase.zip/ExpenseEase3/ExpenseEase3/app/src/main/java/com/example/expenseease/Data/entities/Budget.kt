package com.example.expenseease.Data.entities


import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val amount: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val color: String = "#C8E6C9" // Default card color
)