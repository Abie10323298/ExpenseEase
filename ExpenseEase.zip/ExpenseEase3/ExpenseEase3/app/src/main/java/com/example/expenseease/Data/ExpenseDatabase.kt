package com.example.expenseease.Data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.expenseease.Data.DOA.CategoryDao
import com.example.expenseease.Data.DOA.ExpenseDao
import com.example.expenseease.Data.entities.Category
import com.example.expenseease.Data.entities.Expense

@Database(
    entities = [Category::class, Expense::class], // Add all your entities here
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class) // For custom type conversions if needed
abstract class ExpenseDatabase : RoomDatabase() {
    // Declare all your DAOs here
    abstract fun categoryDao(): CategoryDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var instance: ExpenseDatabase? = null

        fun getDatabase(context: Context): ExpenseDatabase {
            return instance ?: synchronized(this) {
                // Create database instance
                val newInstance = Room.databaseBuilder(
                    context.applicationContext,
                    ExpenseDatabase::class.java,
                    "expense_database" // Database name
                )
                    .fallbackToDestructiveMigration() // For development only
                    .build()

                instance = newInstance
                newInstance
            }
        }

        // For testing purposes
        fun destroyInstance() {
            instance = null
        }
    }
}