package com.example.expenseease.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.expenseease.data.entities.User

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username")
    suspend fun getUser(username: String): User?

    @Insert
    suspend fun insert(user: User)
}