package com.example.expenseease
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.expenseease.ui.theme.CategoryAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class CategoryListActivity : AppCompatActivity() {

    private lateinit var viewModel: CategoryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_list)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewCategories)
        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel = ViewModelProvider(this)[CategoryViewModel::class.java]

        viewModel.categories.observe(this) { categories ->
            recyclerView.adapter = CategoryAdapter(categories) { categoryToDelete ->
                viewModel.delete(categoryToDelete)
                Toast.makeText(this, "${categoryToDelete.name} deleted", Toast.LENGTH_SHORT).show()
            }
        }

        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAddCat)
        fabAdd.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

}

class CategoryViewModel {

}
