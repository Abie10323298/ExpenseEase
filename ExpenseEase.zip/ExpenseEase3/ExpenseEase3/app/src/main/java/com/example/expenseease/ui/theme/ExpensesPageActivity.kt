package com.example.expenseease

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class ExpensesPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expenses_page)

        val toolbar = findViewById<Toolbar>(R.id.expenses_toolbar)
        setSupportActionBar(toolbar)


    }
}
