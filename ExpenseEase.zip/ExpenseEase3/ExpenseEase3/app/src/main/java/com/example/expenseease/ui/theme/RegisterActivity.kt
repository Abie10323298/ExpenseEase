package com.example.expenseease

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.expenseease.data.AppDatabase
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val db = AppDatabase.getDatabase(this)
        val userDao = db.userDao()

        findViewById<Button>(R.id.registerButton).setOnClickListener {
            val username = findViewById<EditText>(R.id.registerUsername).text.toString()
            val password = findViewById<EditText>(R.id.registerPassword).text.toString()
            val confirm = findViewById<EditText>(R.id.confirmPassword).text.toString()

            lifecycleScope.launch {
                if (password != confirm) {
                    runOnUiThread {
                        Toast.makeText(
                            this@RegisterActivity,
                            "Passwords don't match",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    return@launch
                }

                if (userDao.getUser(username) != null) {
                    runOnUiThread {
                        Toast.makeText(
                            this@RegisterActivity,
                            "Username taken",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    userDao.insert(User(username, password))
                    finish() // Return to login
                }
            }
        }
    }
}