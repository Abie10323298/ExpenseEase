package com.example.expenseease.data

import com.example.expenseease.data.entities.Expense

class ExpenseRepository(private val expenseDao: ExpenseDao) {
    suspend fun insertExpense(expense: Expense) = expenseDao.insert(expense)
    suspend fun updateExpense(expense: Expense) = expenseDao.update(expense)
    suspend fun deleteExpense(expense: Expense) = expenseDao.delete(expense)

    fun getAllExpenses() = expenseDao.getAllExpenses()
    fun getExpenseById(id: Int) = expenseDao.getExpenseById(id)
    fun getTotalExpenses() = expenseDao.getTotalExpenses()
    fun getExpensesByCategory(category: String) = expenseDao.getExpensesByCategory(category)
}