import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.expenseease.R

class BudgetActivity : AppCompatActivity() {

    private lateinit var budgetRecyclerView: RecyclerView
    private lateinit var budgetTitle: EditText
    private lateinit var budgetAmount: EditText
    private lateinit var addButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget)

        budgetTitle = findViewById(R.id.budgetTitle)
        budgetAmount = findViewById(R.id.budgetAmount)
        addButton = findViewById(R.id.btnAddBudget)
        budgetRecyclerView = findViewById(R.id.budgetRecyclerView)

        // Setup RecyclerView, Listeners, etc.
    }
}