// BudgetDao.kt
package com.example.expenseease.data.dao

import androidx.room.*
import com.example.expenseease.data.entities.Budget

@Dao
interface BudgetDao {
    @Insert
    suspend fun insert(budget: Budget): Long

    @Update
    suspend fun update(budget: Budget)

    @Delete
    suspend fun delete(budget: Budget)

    @Query("SELECT * FROM budgets ORDER BY createdAt DESC")
    suspend fun getAllBudgets(): List<Budget>

    @Query("SELECT * FROM budgets WHERE id = :id LIMIT 1")
    suspend fun getBudgetById(id: Int): Budget?

    @Query("SELECT SUM(amount) FROM budgets")
    suspend fun getTotalBudget(): Double
}