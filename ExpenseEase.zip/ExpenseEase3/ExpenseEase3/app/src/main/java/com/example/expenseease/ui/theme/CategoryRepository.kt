package com.example.expenseease

import androidx.lifecycle.LiveData
import com.example.expenseease.Data.DOA.CategoryDao
import com.example.expenseease.Data.entities.Category


class CategoryRepository(private val categoryDao: CategoryDao) {
    val getAllCategories: LiveData<List<Category>> = categoryDao.getAllCategories()

    suspend fun insertCategory(category: Category) {
        categoryDao.insertCategory(category)
    }
    suspend fun delete(category: Category){
        categoryDao.delete(category)
    }
}